<h2>Selamat Datang Adinistrator</h2>
<pre><php print_r($_SESSION); ?></pre>