<h2>Merk Produk</h2>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Id</th>
            <th>Nama</th>
        </tr>
    </thead>
    <tbody>
        <?php $nomor=1; ?>
        <?php $ambil=$koneksi->query("SELECT * FROM merk_parfum"); ?>
        <?php while($pecah = $ambil->fetch_assoc()){ ?>
        <tr>
            <td><?php echo $nomor; ?></td>
            <td><?php echo $pecah['id_merk']; ?></td>
            <td><?php echo $pecah['nama_merk']; ?></td>
        <td>
                <a href ="index.php?halaman=hapusmerk&id=<?php echo $pecah['id_merk']; ?>" class="btn-danger btn">hapus</a>
                <a href ="index.php?halaman=ubahmerk&id=<?php echo $pecah['id_merk']; ?>" class="btn btn-warning">ubah</a>
         </td>
        </tr>
        <?php $nomor++; ?>
        <?php } ?>

    </tbody>
</table>
<a href="index.php?halaman=tambahukuran" class="btn btn-primary">Tambah Data</a>