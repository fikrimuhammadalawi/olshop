<?php
session_start();
// mendapatkan id_parfum dari url
$id_parfum= $_GET['id'];


// jk sudah ada produk itu di keranjang, maka produk itu jumlahnya di +1
if(isset($_SESSION['keranjang'][$id_parfum]))
{
        $_SESSION['keranjang'][$id_parfum]+=1;
}
// selain itu (blm ada di keranjang), mk produk itu dianggap beli 1
else
{
        $_SESSION['keranjang'][$id_parfum] = 1;
}



//echo "<pre>";
//print_r($_SESSION);
//echo "</pre>";

//larikan ke halaman keranjang
echo "<script>alert('produk telah masuk ke keranjang belanja');</script>";
echo "<script>location='keranjang.php';</script>";

?>