<?php
session_start();
$koneksi=new mysqli("localhost","root","","toko_parfume");

//jika blm login, login dlu

?>
<!DOCTYPE html>
<html>
<head>
	<title>Checkout </title>
	<link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>
<BODY STYLE="BACKGROUND-IMAGE:URL(checkout.JPG)">

<?php include 'menu.php' ?>

<section class="konten">
	<div class="container">
	<h1> Check Out </h1>
		<hr>
		<table class= "table table-bordered" style="background-color:cornsilk;" >
			<thead>
				<tr>
					<th>No.</th>
					<th>Nama Barang</th>
					<th>Harga</th>
					<th>Jumlah</th>
					<th>Sub Total</th>
				</tr>
			</thead>
			<tbody>
				<?php $nomor=1;?>
				<?php $totalbelanja=0;?>
				<?php foreach ($_SESSION["keranjang"] as $id_barang=> $jumlah):?>
				<!-- menampilkan barang yg sedang diperulangkan brdsrkan id_barang-->
				<?php
					$ambil=$koneksi->query("SELECT*FROM parfum WHERE id_parfum='$id_barang'");
					$pecah=$ambil->fetch_assoc();
					$subharga=$pecah["harga"]*$jumlah;
				?>
				<tr>
					<td><?php echo $nomor;?></td>
					<td><?php echo $pecah["nama_parfum"];?> </td>
					<td>Rp.<?php echo number_format($pecah['harga']);?> </td>
					<td><?php echo $jumlah; ?></td>
					<td>Rp.<?php echo number_format($subharga);?> </td>
				</tr>
				<?php $nomor++;?>
				<?php $totalbelanja+=$subharga;?>
				<?php endforeach ?>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="4"> Total Belanja</th>
					<th>Rp.<?php echo number_format( $totalbelanja)?>
				</tr>
			</tfoot>
		</table>
		
		
		<form method="post">
		
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<input type="text" readonly value="<?php echo $_SESSION ["pembeli"]["nama"] ?>"
						class= "form-control">
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<input type="text" readonly value="<?php echo $_SESSION ["pembeli"]["alamat"]?>" class="form-control">
					</div>
				</div>
				<div class="col-md-4">
					<select class="form-control" name="id_ongkir">
						<option value=""> Pilih Ongkos Kirim</option>
						<?php
						$ambil=$koneksi->query("SELECT * FROM pengiriman");
						while($perongkir=$ambil->fetch_assoc()){
						?>
						<option value="<?php echo $perongkir['ongkir']?>">
							<?php echo $perongkir['id_tujuan']?> -
							Rp.<?php echo number_format( $perongkir['ongkir'])?>
						</option>
						<?php }?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label> Alamat Lengkap Pengiriman</label>
				<textarea class="form-control" name="alamatpengiriman" placeholder="Masukkan Alamat Lengkap Pengiriman"></textarea>
			</div>
		<button class="btn btn-primary" name="checkout" > Check Out</button>
		</form>
		
		<?php
		if(isset($_POST["checkout"]))
		{
			$usernamee=$_SESSION["pembeli"]["usernamee"];
			$id_ongkir=$_POST["id_ongkir"];
			$tanggal=date("Y-m-d");
			$alamatpengiriman=$_POST["alamatpengiriman"];
			
			$ambil=$koneksi->query("SELECT * FROM pengiriman WHERE id_ongkir='$id_ongkir'");
			$arrayongkir=$ambil->fetch_assoc();
			$tarif=$arrayongkir['tarif'];
			
			
			$total_bayar=$totalbelanja + $tarif;
			$a="F000";
			$b=$usernamee;
			$id_faktur=$a.$b.rand(100,999);
			//menyimpan data ketabelfaktur
			$koneksi->query("INSERT INTO faktur ( id_faktur, usernamee, id_ongkir, tanggal, total_bayar, alamat_pengiriman) 
			VALUES ( '$id_faktur', '$usernamee', '$id_ongkir','$tanggal','$total_bayar','$alamatpengiriman')");
				
					$ambil=$koneksi->query("SELECT*FROM faktur");
					$pecahh=$ambil->fetch_assoc();
					$idfaktur=$pecahh['id_faktur'];
				
			
			foreach($_SESSION["keranjang"] as $id_barang=>$jumlah_barang)
			{
				$koneksi->query("INSERT INTO beli (id_faktur, id_barang, jumlah_barang) 
				VALUES ('$id_faktur', '$id_barang','$jumlah_barang')");
				
				//skrip update stok
				$koneksi->query("UPDATE barang SET stok=stok-$jumlah_barang WHERE id_barang='$id_barang'");
			}
			
			//mengosongkan keranjang belanja
				unset($_SESSION["keranjang"]);
			
			echo "<script>alert('Pembelian Sukses');</script>";
			echo "<script>location='faktur.php?id=$idfaktur';</script>";
			

		}
		?>
		
	</div>
</section>






</body>
</html>